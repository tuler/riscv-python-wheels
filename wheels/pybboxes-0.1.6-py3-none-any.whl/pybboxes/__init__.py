from pybboxes.boxes import (
    AlbumentationsBoundingBox,
    BoundingBox,
    CocoBoundingBox,
    FiftyoneBoundingBox,
    VocBoundingBox,
    YoloBoundingBox,
)
from pybboxes.functional import convert_bbox  # Backwards compatibility

__version__ = "0.1.6"
